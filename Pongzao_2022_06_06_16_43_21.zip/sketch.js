let comprimentoTela= 800;
let larguraTela= 600;
let xBolinha= comprimentoTela/2;
let yBolinha= larguraTela/2;
let diametro= 20;
let raio= diametro/2;
let xRaquete= 10;
let yRaquete= 300;
let larguraRaquete= 20;
let comprimentoRaquete= 100;
let velocidadeXBolinha = 7;
let velocidadeYBolinha = 7;
let xRaquete2 = comprimentoTela - 30;
let yRaquete2= 300;
let larguraRaquete2= 20;
let comprimentoRaquete2= 100;
let colidiu = false;

function setup() {
  createCanvas(comprimentoTela, larguraTela);
}

function draw() {
  background(50);
  criaBolinha();
  moveBolinha();
  colideBolinha();
  criaMinhaRaquete(xRaquete, yRaquete);
  moveRaquete();
  colideRaquete();
  criaRaquete2(xRaquete2, yRaquete2);
  colideRaquete2();
}
function criaBolinha() {
  circle(xBolinha, yBolinha, diametro);
}
function moveBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
  yRaquete2 = yBolinha - comprimentoRaquete2 / 2;
}
function colideBolinha() {
  if (xBolinha + raio > comprimentoTela || xBolinha - raio < 0){
    velocidadeXBolinha = velocidadeXBolinha *-1
  }
  if (yBolinha + raio > larguraTela || yBolinha - raio < 0){
    velocidadeYBolinha = velocidadeYBolinha *-1
  }
}

function criaMinhaRaquete() {
  rect(xRaquete, yRaquete, larguraRaquete, comprimentoRaquete);
}

function moveRaquete() {
  if (keyIsDown(UP_ARROW)){
    yRaquete += -13
  }
   if (keyIsDown(DOWN_ARROW)){
    yRaquete += 13
   }
}
function colideRaquete (){
    if (xBolinha - raio < xRaquete + larguraRaquete
        && yBolinha - raio < yRaquete + comprimentoRaquete
        && yBolinha + raio > yRaquete){
        velocidadeXBolinha *= -1;
    }
}

function criaRaquete2() {
  rect(xRaquete2, yRaquete2, larguraRaquete2, comprimentoRaquete2);
}

function colideRaquete2 (){
  colidiu = collideRectCircle (xRaquete2, yRaquete2,
larguraRaquete2, comprimentoRaquete2, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *=-1
  }
}